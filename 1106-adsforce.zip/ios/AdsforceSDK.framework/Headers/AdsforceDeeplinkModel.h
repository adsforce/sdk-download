//
//  AdsforceDeeplinkModel.h
//  AdsforceSDK
//
//  Created by liuguojun on 2018/6/1.
//  Copyright © 2018 Adsforce. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdsforceDeeplinkModel : NSObject

@property (nonatomic,copy) NSString *targetUrl;
@property (nonatomic,copy) NSString *linkArgs;

@end
