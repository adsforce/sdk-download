//
//  AdsforceSDKVersion.h
//  AdsforceSDK
//
//  Created by liuguojun on 2018/6/4.
//  Copyright © 2018 Adsforce. All rights reserved.
//

#define AdsforceSDK_VERSION @"1106"
